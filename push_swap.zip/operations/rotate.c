/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: emda-sil <emda-sil@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/15 11:56:15 by emda-sil          #+#    #+#             */
/*   Updated: 2026/06/15 11:56:22 by emda-sil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	rotate(t_stack **stack)
{
	t_stack	*tmp;

	if (!stack || !*stack || !(*stack)->next)
		return ;
	tmp = (*stack);
	*stack = (*stack)->next;
	tmp->next = NULL;
	add_back(stack, tmp);
}

void	rotate_ra(t_bench *bench, t_stack **a)
{
	if (!a || !*a || !(*a)->next)
		return ;
	rotate(a);
	write(1, "ra\n", 3);
	if (bench != NULL)
		++bench->moves[ra];
}

void	rotate_rb(t_bench *bench, t_stack **b)
{
	if (!b || !*b || !(*b)->next)
		return ;
	rotate(b);
	write(1, "rb\n", 3);
	if (bench != NULL)
		++bench->moves[rb];
}

void	rotate_rr(t_bench *bench, t_stack **a, t_stack **b)
{
	if ((!a || !*a || !(*a)->next) && (!b || !*b || (!(*b)->next)))
		return ;
	rotate(a);
	rotate(b);
	write(1, "rr\n", 3);
	if (bench != NULL)
		++bench->moves[rr];
}
